package day3_Tasks;
//Write a Java program to convert a string to an integer in Java

public class String_to_Int {

	public static void main(String[] args) {
		String st = "789123";
		int i = Integer.parseInt(st) ;
		System.out.println(i);

	}

}
